import React from "react";
import "./Nautstring.css"

class Nautstring extends React.Component{
	constructor(props){
		super(props);
		this.state={
			inputstring : []
		}
		this.updateInput = this.updateInput.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);	
	};

	updateInput(event){
	this.setState({inputstring : event.target.value})
	}

	handleSubmit(){
	console.log('Your input value is: ' + this.inputstring)
	}

	render(){
		return(
		<div className="Nautstring">
        <header className="Nautstring-header">
             <form>
             	<h1>Hello World</h1>
		        <input type="text" name="cstring" id="cstring" onChange={this.updateInput} />
		        <button onClick={this.handleSubmit} > Submit </button> 
             </form>
        </header>
        </div>
 		);
	}
};

export default Nautstring;