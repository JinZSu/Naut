import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import Nautstring from './Nautstring';


ReactDOM.render(<Nautstring />, document.getElementById('root'));
